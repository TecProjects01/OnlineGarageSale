import { useState } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'

import Header from './components/Header.jsx'
import Footer from './components/Footer.jsx'

import Sobre from './pages/Sobre.jsx'
import Venda from './pages/Venda.jsx'
import Cadastro from './pages/Cadastro.jsx'

const produtosIniciais = [
  {
    id: 1,
    nome: 'Miniatura Dragão',
    descricao: 'Miniatura 3D pintada à mão',
    contato: '(19) 99999-0001',
  },
  {
    id: 2,
    nome: 'Vaso Geométrico',
    descricao: 'Vaso decorativo em PLA',
    contato: '(19) 99999-0002',
  },
  {
    id: 3,
    nome: 'Suporte de Celular',
    descricao: 'Suporte ajustável para mesa',
    contato: '(19) 99999-0003',
  },
  {
    id: 4,
    nome: 'Chaveiro Robô',
    descricao: 'Chaveiro articulado impresso em 3D',
    contato: '(19) 99999-0004',
  },
]

function App() {
  const [produtos, setProdutos] = useState(produtosIniciais)

  function adicionarProduto(produto) {
    const novoProduto = {
      ...produto,
      id: Date.now(),
    }

    setProdutos((produtosAnteriores) => [
      ...produtosAnteriores,
      novoProduto,
    ])
  }

  return (
    <BrowserRouter>
      <Header />

      <main>
        <Routes>
          <Route path="/" element={<Sobre />} />

          <Route
            path="/vendas"
            element={<Venda produtos={produtos} />}
          />

          <Route
            path="/cadastro"
            element={<Cadastro aoCadastrar={adicionarProduto} />}
          />
        </Routes>
      </main>

      <Footer />
    </BrowserRouter>
  )
}

export default App