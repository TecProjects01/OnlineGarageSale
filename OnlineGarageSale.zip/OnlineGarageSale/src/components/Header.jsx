import { NavLink } from 'react-router-dom'
import './Header.css'

function Header() {
  return (
    <header className="header">
      <div className="header-logo">
        <div className="header-diamond"></div>
        <h1 className="header-titulo">LOJA 3D PRINT</h1>
      </div>

      <nav className="header-nav">
        <NavLink
          to="/"
          className={({ isActive }) => 'header-aba' + (isActive ? ' header-aba-ativa' : '')}
        >
          Sobre
        </NavLink>
        <NavLink
          to="/vendas"
          className={({ isActive }) => 'header-aba' + (isActive ? ' header-aba-ativa' : '')}
        >
          Vendas
        </NavLink>
        <NavLink
          to="/cadastro"
          className={({ isActive }) => 'header-aba' + (isActive ? ' header-aba-ativa' : '')}
        >
          Cadastro
        </NavLink>
      </nav>
    </header>
  )
}

export default Header
