import { NavLink } from 'react-router-dom'
import './Header.css'

function Header() {
  return (
    <header className="header">
      <div className="header-inner">
        <NavLink to="/" end className="header-brand">
          <span className="header-mark">
            <span className="header-mark-layer header-mark-layer-1"></span>
            <span className="header-mark-layer header-mark-layer-2"></span>
            <span className="header-mark-layer header-mark-layer-3"></span>
          </span>
          <span className="header-brand-text">
            Online<strong>Garage</strong>Sale
          </span>
        </NavLink>

        <nav className="header-nav">
          <NavLink to="/vendas" end className={({ isActive }) => 'header-link' + (isActive ? ' is-active' : '')}>
            Vendas
          </NavLink>
          <NavLink to="/cadastro" className={({ isActive }) => 'header-link' + (isActive ? ' is-active' : '')}>
            Cadastro
          </NavLink>
          <NavLink to="/sobre" className={({ isActive }) => 'header-link' + (isActive ? ' is-active' : '')}>
            Sobre
          </NavLink>
        </nav>
      </div>


    </header>
  )
}

export default Header