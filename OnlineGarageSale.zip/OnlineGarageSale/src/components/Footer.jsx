import './Footer.css'

function Footer() {
  const ano = new Date().getFullYear()

  return (
    <footer className="footer">
      <div className="footer-inner">
        <span className="footer-brand">OnlineGarageSale</span>
        <span>© {ano} Todos os direitos reservados</span>
      </div>

      
    </footer>
  )
}

export default Footer