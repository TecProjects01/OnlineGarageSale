import './Footer.css'

function Footer() {
  const ano = new Date().getFullYear()

  return (
    <footer className="footer">
      <p className="footer-texto">LOJA 3D PRINT © {ano} — Todos os direitos reservados</p>

    </footer>
  )
}

export default Footer
