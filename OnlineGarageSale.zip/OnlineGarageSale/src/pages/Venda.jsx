import { useState } from 'react'
import './Venda.css'

function Venda({ produtos }) {
  const [busca, setBusca] = useState('')

  const produtosFiltrados = produtos.filter((produto) =>
    produto.nome.toLowerCase().includes(busca.toLowerCase())
  )

  return (
    <section className="venda">
      <div className="venda-topo">
        <h2 className="venda-titulo">Produtos à venda</h2>
        <div className="venda-abas">
          <button className="venda-aba" onClick={() => setBusca('')}>
            Todos
          </button>
          <button className="venda-aba" onClick={() => setBusca('dragão')}>
            Fantasia
          </button>
          <button className="venda-aba" onClick={() => setBusca('vaso')}>
            Utilidades
          </button>
        </div>
      </div>

      <div className="venda-grid">
        {produtosFiltrados.length === 0 && (
          <p className="venda-vazio">Nenhum produto encontrado.</p>
        )}

        {produtosFiltrados.map((produto) => (
          <div key={produto.id} className="venda-card">
            <div className="venda-imagem">3D</div>
            <p className="venda-nome">{produto.nome}</p>
            <p className="venda-descricao">{produto.descricao}</p>
          </div>
        ))}
      </div>
    </section>
  )
}

export default Venda
