import { useState } from 'react'
import './Venda.css';

const categorias = ['Todos', 'Decoração', 'Utilidades']

function Venda({ produtos }) {
  const [categoria, setCategoria] = useState('Todos')
  const [busca, setBusca] = useState('')

  const produtosFiltrados = produtos.filter((produto) => {
    const combinaCategoria = categoria === 'Todos' || produto.categoria === categoria
    const combinaBusca = produto.nome.toLowerCase().includes(busca.toLowerCase())
    return combinaCategoria && combinaBusca
  })

  return (
    <section className="venda">
      <div className="venda-cabecalho">
        <div>
          <h1 className="venda-titulo">Catálogo</h1>
        </div>
        <input
          type="text"
          className="venda-busca"
          placeholder="Buscar produto..."
          value={busca}
          onChange={(evento) => setBusca(evento.target.value)}
        />
      </div>

      <div className="venda-filtros">
        {categorias.map((c) => (
          <button
            key={c}
            className={'venda-filtro' + (categoria === c ? ' is-active' : '')}
            onClick={() => setCategoria(c)}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="venda-grid">
        {produtosFiltrados.length === 0 && (
          <p className="venda-vazio">Nenhum produto encontrado para esse filtro.</p>
        )}

        {produtosFiltrados.map((produto) => (
          <article key={produto.id} className="venda-card">
            <div className="venda-imagem">
              <span className="venda-imagem-camada c1"></span>
              <span className="venda-imagem-camada c2"></span>
              <span className="venda-imagem-camada c3"></span>
            </div>
            <div className="venda-card-corpo">
              <span className="venda-card-categoria">{produto.categoria}</span>
              <h3 className="venda-card-nome">{produto.nome}</h3>
              <p className="venda-card-descricao">{produto.descricao}</p>
              <span className="venda-card-preco">{produto.preco}</span>
            </div>
          </article>
        ))}
      </div>

      
    </section>
  )
}

export default Venda