import './Sobre.css'

function Sobre() {
  return (
    <section className="sobre">
      <h2 className="sobre-titulo">Fundação</h2>

      <div className="sobre-botoes">
        <button className="sobre-botao">Missão</button>
        <button className="sobre-botao">Valores</button>
        <button className="sobre-botao">História</button>
      </div>

      <div className="sobre-explicacao">
        <h3>Explicação</h3>
        <p>
          A Loja 3D Print nasceu da paixão por impressão 3D e por transformar ideias
          em objetos reais. Produzimos miniaturas, peças decorativas e utilitários
          impressos sob demanda, com controle de qualidade em cada etapa do processo.
        </p>
        <p>
          Nosso objetivo é aproximar a tecnologia de impressão 3D do dia a dia das
          pessoas, oferecendo produtos personalizados com agilidade e preço justo.
        </p>
      </div>
    </section>
  )
}

export default Sobre
