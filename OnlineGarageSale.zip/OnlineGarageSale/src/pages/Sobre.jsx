import './Sobre.css';

function Sobre() {
  return (
    <section className="sobre">
      <div className="sobre-card">
        <p className="sobre-tag">Sobre a loja</p>
        <h1 className="sobre-titulo">Uma forma simples de vender o que não usa mais.</h1>
        <p className="sobre-texto">
          Essa é uma loja virtual com a ideia de vender itens pessoais que já não são
          utilizados. O objetivo é facilitar a forma com que esses itens serão vendidos, baseando-se 
          em vendas de garagem.
        </p>
      </div>
    </section>
  )
}

export default Sobre