import { useState } from 'react'
import './Cadastro.css';

const categorias = ['Decoração', 'Utilidades']
const valoresIniciais = { nome: '', categoria: categorias[0], preco: '', descricao: '', contato: '' }

function Cadastro({ aoCadastrar }) {
  const [formulario, setFormulario] = useState(valoresIniciais)
  const [mensagem, setMensagem] = useState('')

  function atualizarCampo(evento) {
    const { name, value } = evento.target
    setFormulario((anterior) => ({ ...anterior, [name]: value }))
  }

  function enviarFormulario(evento) {
    evento.preventDefault()

    if (!formulario.nome.trim() || !formulario.descricao.trim()) {
      setMensagem('Preencha ao menos o nome e a descrição do produto.')
      return
    }

    aoCadastrar(formulario)
    setFormulario(valoresIniciais)
    setMensagem('Produto cadastrado com sucesso.')
  }

  return (
    <section className="cadastro">
      <div className="cadastro-cabecalho">
        <h1 className="cadastro-titulo">Cadastrar produto</h1>
        <p className="cadastro-subtitulo">
          Preencha os dados abaixo para adicionar uma nova peça ao catálogo de vendas.
        </p>
      </div>

      <div className="cadastro-grid">
        <form className="cadastro-formulario" onSubmit={enviarFormulario}>
          <label className="cadastro-campo">
            <span>Nome</span>
            <input type="text" name="nome" value={formulario.nome} onChange={atualizarCampo} placeholder="Digite aqui o nome do seu produto" />
          </label>

          <div className="cadastro-linha">
            <label className="cadastro-campo">
              <span>Categoria</span>
              <select name="categoria" value={formulario.categoria} onChange={atualizarCampo}>
                {categorias.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
            </label>

            <label className="cadastro-campo">
              <span>Preço</span>
              <input type="text" name="preco" value={formulario.preco} onChange={atualizarCampo} placeholder="Digite o preço do produto" />
            </label>
          </div>

          <label className="cadastro-campo">
            <span>Descrição</span>
            <input
              type="text"
              name="descricao"
              value={formulario.descricao}
              onChange={atualizarCampo}
              placeholder="Digite a descrição do seu produto"
            />
          </label>

          <label className="cadastro-campo">
            <span>Contato</span>
            <input type="text" name="contato" value={formulario.contato} onChange={atualizarCampo} placeholder="Digite o contato do vendedor" />
          </label>

          <button type="submit" className="cadastro-botao">
            Cadastrar produto
          </button>

          {mensagem && <p className="cadastro-mensagem">{mensagem}</p>}
        </form>
      </div>


    </section>
  )
}

export default Cadastro