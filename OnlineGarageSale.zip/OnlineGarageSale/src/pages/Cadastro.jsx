import { useState } from 'react'
import './Cadastro.css'

const valoresIniciais = { nome: '', descricao: '', contato: '', foto: '' }

function Cadastro({ aoCadastrar }) {
  const [formulario, setFormulario] = useState(valoresIniciais)
  const [mensagem, setMensagem] = useState('')

  function atualizarCampo(evento) {
    const { name, value } = evento.target
    setFormulario((anterior) => ({ ...anterior, [name]: value }))
  }

  function enviarFormulario(evento) {
    evento.preventDefault()

    if (!formulario.nome.trim() || !formulario.descricao.trim()) {
      setMensagem('Preencha ao menos o nome e a descrição do produto.')
      return
    }

    aoCadastrar(formulario)
    setFormulario(valoresIniciais)
    setMensagem('Produto cadastrado com sucesso!')
  }

  return (
    <section className="cadastro">
      <div className="cadastro-explicacao">
        <h3>O que é essa aba?</h3>
        <p>
          Aqui você cadastra os produtos que serão exibidos na aba de Vendas.
          Preencha o nome, a descrição e o contato para negociação, além de
          uma foto representativa do item impresso em 3D.
        </p>
      </div>

      <form className="cadastro-formulario" onSubmit={enviarFormulario}>
        <label>
          Nome
          <input
            type="text"
            name="nome"
            value={formulario.nome}
            onChange={atualizarCampo}
            placeholder="Ex: Miniatura Dragão"
          />
        </label>

        <label>
          Descrição
          <input
            type="text"
            name="descricao"
            value={formulario.descricao}
            onChange={atualizarCampo}
            placeholder="Ex: Miniatura 3D pintada à mão"
          />
        </label>

        <label>
          Contatos
          <input
            type="text"
            name="contato"
            value={formulario.contato}
            onChange={atualizarCampo}
            placeholder="Ex: (19) 99999-0000"
          />
        </label>

        <button type="submit" className="cadastro-botao">
          Cadastrar produto
        </button>

        {mensagem && <p className="cadastro-mensagem">{mensagem}</p>}
      </form>

      <div className="cadastro-foto">FOTO</div>
    </section>
  )
}

export default Cadastro
